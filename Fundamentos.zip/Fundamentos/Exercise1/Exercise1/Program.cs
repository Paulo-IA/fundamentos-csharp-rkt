﻿namespace Exercise1;

public class Program
{
    static void Main()
    {
        Console.WriteLine("Digite o seu nome: ");

        var name = Console.ReadLine();

        Console.WriteLine($"Olá {name}! Seja muito bem-vindo!");
    }
}