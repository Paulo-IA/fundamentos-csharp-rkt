﻿using System.Text.RegularExpressions;

namespace Exercise5;

public class Program
{
    static void Main()
    {        
        Console.WriteLine("Digite uma placa: ");
        var placa = Console.ReadLine();

        while (placa == null)
        {
            Console.WriteLine("\tO valor da placa não pode ser nulo.");
            placa = Console.ReadLine();
        }

        if (IsAlphaNumeric(placa) && placa.Length == 7 && ValidaPlaca(placa))
        {
            Console.WriteLine("VERDADEIRO");
        } else
        {
            Console.WriteLine("FALSO");
        }
    }

    public static Boolean IsAlphaNumeric(string s)
    {
        Regex rg = new Regex(@"^[a-zA-Z0-9\s,]*$");
        return rg.IsMatch(s);
    }

    public static Boolean ValidaPlaca(string s)
    {
        var count = 0;
        var numbersInChar = new List<char>() { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

        for (var i=3; i<=6; i++)
        {
            foreach (var number in numbersInChar)
            {
                if (s[i] == number)
                {
                    count++;
                }
            }

        }

        var countLetra = 0;

        for (var j=0;j<=2;j++)
        {
            foreach (var number in numbersInChar)
            {
                if (s[j] != number)
                {
                    countLetra++;
                }
            }
        }

        return count == 4 && countLetra == 30;
    }
}