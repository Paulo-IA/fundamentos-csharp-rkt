﻿namespace Exercise3;

public class Program
{
    static void Main()
    {
        bool quit = false;

        while(!quit)
        {
            Console.WriteLine("\n\nDigitar [1] / Aleatórios [2] / Sair [q]");
            var chose = Console.ReadLine();

            switch (chose)
            {
                case "1":
                    Console.WriteLine("Type the first number!");

                    var number1 = double.Parse(Console.ReadLine());

                    Console.WriteLine("Type the second number!");
                    var number2 = double.Parse(Console.ReadLine());

                    if (number2 == 0)
                    {
                        Console.WriteLine("\nSorry, the number 2 can't be zero.");
                        continue;
                    }

                    Console.WriteLine("You chose:");

                    Console.WriteLine($"Number 1: {number1}");
                    Console.WriteLine($"Number 2: {number2}");

                    PrintSolutions(number1, number2);

                    quit = true;
                    
                    break;
                case "2":
                    Console.WriteLine("The system chose:");

                    Random random = new Random();

                    var n1 = random.Next() + random.NextDouble();
                    var n2 = 0.0;

                    while(IsZero(n2))
                        n2 = random.Next() + random.NextDouble();   
                    

                    Console.WriteLine($"Number 1: {n1}");
                    Console.WriteLine($"Number 2: {n2} ");

                    PrintSolutions(n1, n2);

                    quit = true;
                    break;
                case "q":
                    Console.WriteLine("Programa finalizado!");
                    quit = true;
                    break;
                default:
                    Console.WriteLine("Valor incorreto, tente novamente!");
                    break;
                    
            }
        }      

    }

    static void PrintSolutions(double number1, double number2)
    {
        Console.WriteLine($"\t{number1} + {number2} = {number1 + number2}");
        Console.WriteLine($"\t{number1} - {number2} = {number1 - number2}");
        Console.WriteLine($"\t{number1} * {number2} = {number1 * number2}");
        Console.WriteLine($"\t{number1} / {number2} = {number1 / number2}");
    }

    static bool IsZero(double number)
    {
        if (number == 0) return true;

        return false;
    }
}