﻿namespace Exercise2;

public class Program
{
    static void Main()
    {
        Console.WriteLine("Nome: ");
        var name = Console.ReadLine();

        Console.WriteLine("Sobrenome: ");
        var surname = Console.ReadLine();

        Console.WriteLine($"Prazer, {name} {surname}");
    }
}