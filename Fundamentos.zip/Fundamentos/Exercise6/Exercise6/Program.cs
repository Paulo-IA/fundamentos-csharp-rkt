﻿namespace Exercise6;

public class Program
{
    static void Main()
    {
        Console.WriteLine("Bem-Vindo ao 'Mostra Data Atual'!");
        Console.WriteLine("O aplicativo que te mostra a data atual em diversos formatos!");

        var dataAtual = DateTime.UtcNow;
        Console.WriteLine(dataAtual.ToString("F"));
        Console.WriteLine(dataAtual.ToString("dd/MM/yyyy"));
        Console.WriteLine(dataAtual.ToString("HH:mm:ss"));
        Console.WriteLine(dataAtual.ToString("dd/MMMM/yyyy"));
    }
}