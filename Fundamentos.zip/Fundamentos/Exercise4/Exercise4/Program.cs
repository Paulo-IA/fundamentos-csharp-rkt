﻿namespace Exercise4;

public class Program
{
    static void Main()
    {
        var quit = false;

        while(!quit)
        {
            Console.WriteLine("Palavra [1] / Sair [q]");
            var again = Console.ReadLine();

            switch(again)
            {
                case "q":
                    quit = true;
                    break;
                case "1":
                    var word = Console.ReadLine();
                    Console.WriteLine($"The word have {word.Length} characters.");
                    continue;
                default:
                    Console.WriteLine("Valor inserido incorreto, tente novamente.");
                    break;
            }
        }
    }
}